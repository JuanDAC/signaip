# Adapters tests package
