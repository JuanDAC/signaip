# Backend de Registro de Marcas
# Arquitectura Hexagonal con FastAPI, SQLAlchemy e Injector
