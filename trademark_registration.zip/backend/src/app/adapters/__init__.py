# Paquete de adaptadores - Implementaciones concretas
