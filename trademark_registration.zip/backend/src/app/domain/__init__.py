# Paquete del dominio - Lógica de negocio y entidades
