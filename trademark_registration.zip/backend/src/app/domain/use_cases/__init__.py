# Casos de uso del dominio
