__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/9547ae93eb6b87fe.js",
  "static/chunks/turbopack-77a99fc591d6cf96.js"
])
