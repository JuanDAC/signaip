__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/9547ae93eb6b87fe.js",
  "static/chunks/turbopack-ebadfd0ccc6c5e86.js"
])
