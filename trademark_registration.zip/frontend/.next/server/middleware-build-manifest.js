globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/9547ae93eb6b87fe.js",
      "static/chunks/turbopack-ebadfd0ccc6c5e86.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/9547ae93eb6b87fe.js",
      "static/chunks/turbopack-77a99fc591d6cf96.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/9a992631db4082b6.js",
    "static/chunks/569f8ca39997ccda.js",
    "static/chunks/202abb9aed9e828b.js",
    "static/chunks/0656f51f27ce398d.js",
    "static/chunks/turbopack-d5f48c03b555f98c.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];